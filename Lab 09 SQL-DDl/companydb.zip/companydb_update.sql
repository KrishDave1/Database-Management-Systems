Update Employee Set Salary = 40000 Where ssn = '123456789';
Update department Set mgr_start_date = '1988-05-23' Where dnumber = 5;