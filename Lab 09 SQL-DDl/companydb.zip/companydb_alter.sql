alter table Employee
add constraint fk_super_ssn FOREIGN KEY(super_ssn) REFERENCES Employee(Ssn);

alter table Employee
add constraint fk_dno FOREIGN KEY(Dno) REFERENCES department(Dnumber);

alter table department
add constraint fk_mgr_ssn FOREIGN KEY(Mgr_ssn) REFERENCES Employee(Ssn);

alter table Dept_Locations
add constraint fk_dnumber FOREIGN KEY(Dnumber) REFERENCES department(Dnumber);

alter table Project
add constraint fk_dnum FOREIGN KEY(Dnum) REFERENCES department(Dnumber);

alter table Works_on
add constraint fk_essn FOREIGN KEY(Essn) REFERENCES Employee(Ssn);

alter table Works_on
add constraint fk_pno FOREIGN KEY(Pno) REFERENCES Project(Pnumber);

alter table Dependent
add constraint fk_essn FOREIGN KEY(Essn) REFERENCES Employee(Ssn);

