insert into Employee
(Fname, Minit, Lname, Ssn, Bdate, Address,Sex, Salary, Super_ssn, Dno)
VALUES('John','B','Smith','123456789','1965-01-09','731-Fondren-Houston-TX','M',30000,NULL,NULL);

insert into department
(dname, dnumber, mgr_ssn, mgr_start_date)
VALUES('Research',5,NULL,'1988-05-22');

insert into Dept_Locations
(dnumber, dlocation)
VALUES(5,'Houston');

insert into Project
(pname, pnumber, plocation, dnum)
VALUES('ProductX',1,'Bellaire',5);

insert into Works_on
(essn, pno, hours)
VALUES('123456789',1,32.5);

insert into Dependent
(essn, Dependent_name, sex, bdate, relationship)
VALUES('123456789','Alice','F','1986-04-05','Daughter');